-- Run this in Supabase SQL editor to create tables and RLS policies
-- Tables: users (optional), boards

create table if not exists boards (
  user_id text primary key,
  resources jsonb not null,
  updated_at timestamptz default now()
);

-- Example initial row:
-- insert into boards (user_id, resources) values ('example-session-id', '[{"name":"money","current":10,"production":1}]');

-- Optional: enable Row Level Security and allow upsert from anon client to own rows.
-- Enable RLS:
-- alter table boards enable row level security;

-- Policy to allow insert/update/delete by anon (for demo/testing only — tighten for production)
-- create policy "Anon can modify own board" on boards for all using (true);

-- Better approach: create policies that restrict by a JWT claim (sub or user_id).
-- For production, set up Supabase Auth and use auth.uid() in policies.