import React from 'react'

export default function ResourceRow({resource, onChangeCurrent, onChangeProd}){
  return (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 p-3 border rounded">
      <div className="flex-1">
        <div className="font-semibold">{resource.name}</div>
        <div className="text-sm text-slate-500">Készlet: <span className="font-mono">{resource.current}</span> &nbsp; | &nbsp; Termelés: <span className="font-mono">{resource.production}</span></div>
      </div>
      <div className="flex gap-2">
        <div className="flex items-center gap-1">
          <button onClick={()=>onChangeCurrent(-5)} className="px-2 py-1 rounded border">-5</button>
          <button onClick={()=>onChangeCurrent(-1)} className="px-2 py-1 rounded border">-1</button>
          <button onClick={()=>onChangeCurrent(1)} className="px-2 py-1 rounded border">+1</button>
          <button onClick={()=>onChangeCurrent(5)} className="px-2 py-1 rounded border">+5</button>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={()=>onChangeProd(-5)} className="px-2 py-1 rounded border">Prod -5</button>
          <button onClick={()=>onChangeProd(-1)} className="px-2 py-1 rounded border">Prod -1</button>
          <button onClick={()=>onChangeProd(1)} className="px-2 py-1 rounded border">Prod +1</button>
          <button onClick={()=>onChangeProd(5)} className="px-2 py-1 rounded border">Prod +5</button>
        </div>
      </div>
    </div>
  )
}