import React, { useEffect, useState, useRef } from 'react'
import { createClient } from '@supabase/supabase-js'
import ResourceRow from './components/ResourceRow'
import { v4 as uuidv4 } from './lib/uuid'

/*
  IMPORTANT:
  - Replace SUPABASE_URL and SUPABASE_ANON_KEY with your Supabase project's values.
  - The SQL schema is included in /supabase/schema.sql
*/

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || 'https://your-supabase-url.supabase.co'
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || 'public-anon-key'
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

const DEFAULT_RESOURCES = [
  'money','steel','titanium','plant','energy','heat'
].map(name => ({ name, current: 0, production: 0 }))

export default function App(){
  const [resources, setResources] = useState(DEFAULT_RESOURCES)
  const [sessionId, setSessionId] = useState(null)
  const [partnerId, setPartnerId] = useState('')
  const [autoOn, setAutoOn] = useState(false)
  const autoRef = useRef(null)

  useEffect(()=> {
    // load or create session id
    let sid = localStorage.getItem('mto_session_id')
    if(!sid){
      sid = uuidv4()
      localStorage.setItem('mto_session_id', sid)
    }
    setSessionId(sid)
    loadBoard(sid)
    // cleanup
    return ()=> clearInterval(autoRef.current)
  },[])

  useEffect(()=> {
    if(autoOn){
      autoRef.current = setInterval(()=> produceAll(), 5000)
    } else {
      clearInterval(autoRef.current)
    }
  },[autoOn, resources])

  async function loadBoard(id){
    try {
      const { data, error } = await supabase
        .from('boards')
        .select('resources')
        .eq('user_id', id)
        .single()
      if(error && error.code !== 'PGRST116') {
        console.error(error)
      }
      if(data && data.resources){
        setResources(data.resources)
      } else {
        // save defaults
        await saveBoard(id, DEFAULT_RESOURCES)
      }
    } catch(err){
      console.error(err)
    }
  }

  async function saveBoard(id, res){
    await supabase.from('boards').upsert({
      user_id: id,
      resources: res
    })
  }

  function updateResource(idx, change){
    const next = resources.map((r,i)=> i===idx ? {...r, current: r.current + change} : r)
    setResources(next)
    saveBoard(sessionId, next)
  }
  function updateProduction(idx, change){
    const next = resources.map((r,i)=> i===idx ? {...r, production: r.production + change} : r)
    setResources(next)
    saveBoard(sessionId, next)
  }
  function produceAll(){
    const next = resources.map(r => ({...r, current: r.current + r.production}))
    setResources(next)
    if(sessionId) saveBoard(sessionId, next)
  }

  async function openPartner(){
    if(!partnerId) return alert('Adj meg partner ID-t.')
    // load partner resources into a readonly view (or allow switching session)
    const { data, error } = await supabase.from('boards').select('resources').eq('user_id', partnerId).single()
    if(error) return alert('Hiba a partner betöltésénél: ' + error.message)
    if(data && data.resources){
      setResources(data.resources)
      // do not change sessionId - we are viewing partner data
    } else {
      alert('Partner nem található.')
    }
  }

  function resetBoard(){
    if(!confirm('Biztosan törlöd az adatokat?')) return
    const cleared = resources.map(r=>({...r, current:0, production:0}))
    setResources(cleared)
    if(sessionId) supabase.from('boards').delete().eq('user_id', sessionId)
    localStorage.removeItem('mto_session_id')
    setTimeout(()=>location.reload(), 400)
  }

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow p-6">
        <h1 className="text-2xl font-semibold mb-4">Mars Terraformálása — Erőforrás Board</h1>
        <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-sm text-slate-600">Session ID: <span className="font-mono">{sessionId}</span></div>
          <div className="flex gap-2 items-center">
            <button onClick={produceAll} className="px-3 py-1 rounded bg-emerald-500 text-white">Termelés</button>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={autoOn} onChange={e=>setAutoOn(e.target.checked)} />
              Automatikus (5s)
            </label>
            <button onClick={resetBoard} className="px-3 py-1 rounded bg-red-500 text-white">Törlés</button>
          </div>
        </div>

        <div className="space-y-2">
          {resources.map((r,idx)=>(
            <ResourceRow key={r.name} resource={r} onChangeCurrent={v=>updateResource(idx,v)} onChangeProd={v=>updateProduction(idx,v)} />
          ))}
        </div>

        <hr className="my-4" />

        <div className="flex gap-2 items-center">
          <input placeholder="Partner ID" value={partnerId} onChange={e=>setPartnerId(e.target.value)} className="border px-2 py-1 rounded flex-1" />
          <button onClick={openPartner} className="px-3 py-1 rounded bg-blue-600 text-white">Megnyitás</button>
          <button onClick={()=>{ if(sessionId) loadBoard(sessionId) }} className="px-3 py-1 rounded bg-slate-300">Vissza saját</button>
        </div>

        <p className="mt-3 text-sm text-slate-500">Megjegyzés: a Supabase URL és kulcs a <code className="font-mono">.env</code> fájlban legyen.</p>
      </div>
    </div>
  )
}